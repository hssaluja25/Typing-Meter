"""typing_meter."""
from hindiApp import HindiApp
HindiApp()