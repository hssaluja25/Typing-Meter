__author__ = "Typing Meter group"
